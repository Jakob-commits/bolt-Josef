export function Users() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="text-center">
        <p className="text-gray-600">Diese Seite ist veraltet. Bitte verwenden Sie die Benutzerverwaltung.</p>
      </div>
    </div>
  );
}
